package TestCases;
import java.io.IOException;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Resources.Base;
import Pages.ClaimSearchPage;

public class ClaimsearchTest extends Base 
{
	@Test(priority=0, dataProvider = "credentials", dataProviderClass = Login.class)
	public void loginMethod(String userName, String password) throws IOException, InterruptedException 
	{
		Login ln = new Login();
		ln.login(userName, password);
	}
	
	@Test(dependsOnMethods = {"loginMethod"}, dataProvider = "claimnumber")
	public void claimSearchMethod(String claimnumber) throws IOException, InterruptedException
	{
		ClaimSearchPage cs = new ClaimSearchPage(driver);
		cs.claimNumberPath().sendKeys(claimnumber);
		Thread.sleep(3000);
		Select sl = new Select(cs.claimOptions());
		sl.selectByVisibleText("Document Management");
		Thread.sleep(3000);
		cs.goButton().click();
		Thread.sleep(4000);

		ArrayList<String> windowHandles = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(windowHandles.get(1));
		
	    WebDriverWait wait = new WebDriverWait(driver,50);
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='props']//tbody//tr[2]//td[2]")));
		WebElement claim = driver.findElement(By.xpath("//*[@id='props']//tbody//tr[2]//td[2]"));
		
		String claimNumberOnVAD = claim.getText();
		Assert.assertEquals(claimnumber, claimNumberOnVAD);
	
		if(claimnumber.equals(claimNumberOnVAD))
		{
		    System.out.println("Claim number on View All Documents and Claim entered are MATCHED! "+claimNumberOnVAD);
		} else 
		{
		    System.out.println("Claim number on View All Documents and Claim entered are NOT MATCHED!");
		}
		 
		driver.close();
		Thread.sleep(3000);
		driver.switchTo().window(windowHandles.get(0));
		System.out.println("Successfully navigated back to Home Page");
	}
	
	@DataProvider(name="claimnumber")
	public Object[][] getClaimNumber()
	{
	    return new Object[][] 
	    {
	        {"001277-001153-WC-01"},
//	        {"mngr137370", "uvetahA"},
//	        {"mngr137371", "utYmEqY"},
	    };
	}
	
	@AfterTest
	public void logOutMethod() throws IOException, InterruptedException 
	{
		Logout ln = new Logout();
		ln.logout();
		System.out.println("Successfully Logged Out");
	}
}
