package TestCases;
import java.io.IOException;
import org.testng.annotations.Test;
import Pages.LogOutPage;
import Resources.Base;

public class Logout extends Base {

	@Test
	public void logout() throws IOException, InterruptedException
	{
		LogOutPage log = new LogOutPage(driver);
		log.logoutclick().click();
		Thread.sleep(3000);
		System.out.println(log.AfterLogoutTitle());
		driver.close();
	}
}
