package TestCases;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.AppChoicePage;
import Pages.LoginPage;
import Resources.Base;

public class Login extends Base {

@Test(dataProvider = "credentials")
public void login(String username, String password) throws IOException, InterruptedException
{
	driver=InitializeDriver();
	launchurl();
	LoginPage lp= new LoginPage(driver);
	lp.userName().sendKeys(username);
	lp.password().sendKeys(password);
 	lp.signIn().click();
// 	AppChoicePage acp = new AppChoicePage(driver);
//	acp.risxfacsclick();
 	Thread.sleep(3000);
 	System.out.println(lp.AfterLoginTitle());
 	
 	if(lp.AfterLoginTitle().equalsIgnoreCase("Gallagher Bassett - AppChoice"))
{
 		System.out.println("Logged in successfully after selecting App in Appchoice");
}
 	else if(lp.AfterLoginTitle().equalsIgnoreCase("Gallagher Bassett - Logon"))
 	{
 		System.out.println("Login not successfull - check the credentials");
 		driver.close();
 	}
 	else
 		System.out.println("Logged in successfully landed in Home Page");
 	
}
@DataProvider(name="credentials")
public static Object[][] getUserData()
{
    return new Object[][] {
        {"901728", "ACMtest4"},
    };
 }
}


