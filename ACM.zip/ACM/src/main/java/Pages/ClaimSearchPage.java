package Pages;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.*;

public class ClaimSearchPage 
{
	public static WebDriver driver;
	public static String claimOptions, claimNumberPath, goButton;

	public ClaimSearchPage(WebDriver driver) throws IOException 
	{
		ClaimSearchPage.initialize();
		ClaimSearchPage.driver = driver;
	}

	public static void initialize() throws IOException 
	{
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream(
				"H:\\Automation\\ACM\\src\\main\\java\\Pages\\claimsearch.prop");
		prop.load(file);
		claimNumberPath = prop.getProperty("claimNumberPath");
		claimOptions = prop.getProperty("claimOptions");
		goButton = prop.getProperty("goButton");	
	}
	
	public WebElement claimNumberPath() 
	{
		return driver.findElement(By.xpath(claimNumberPath));
		
	}
	public WebElement claimOptions() 
	{
		return driver.findElement(By.xpath(claimOptions));
	}
	public WebElement goButton() 
	{
		return driver.findElement(By.xpath(goButton));
	}
}