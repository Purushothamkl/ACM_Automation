package Pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LogOutPage {
	
	public WebDriver driver;
	public static String logOut;

	public LogOutPage(WebDriver driver) throws IOException {
		LogOutPage.initialize();
		this.driver = driver;
	}

	public static void initialize() throws IOException {
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream(
				"H:\\Automation\\ACM\\src\\main\\java\\Pages\\home.prop");
		prop.load(file);
		logOut = prop.getProperty("logout");
	}
	
	public WebElement logoutclick() {
		return driver.findElement(By.xpath(logOut));
	}
	public String AfterLogoutTitle() {
		return driver.getTitle();
	}
}
