package Pages;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	public WebDriver driver;
	public static String userName,password,signIn,usernamevalue,passwordvalue;

	public static void initialize() throws IOException {
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream(
				"H:\\Automation\\ACM\\src\\main\\java\\Pages\\login.prop");
		prop.load(file);
		userName = prop.getProperty("userName");
		password = prop.getProperty("password");
		signIn = prop.getProperty("signIn");
	}

	public LoginPage(WebDriver driver) throws IOException {
		LoginPage.initialize();
		this.driver = driver;
	}

	public WebElement userName() {
		return driver.findElement(By.xpath(userName));
	}
	public WebElement password() {
		return driver.findElement(By.xpath(password));
	}
	public WebElement signIn() {
		return driver.findElement(By.xpath(signIn));
	}
	public String AfterLoginTitle() {
		return driver.getTitle();
	}

}
