package pages;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import base.GenericClass;

public class LoginPage
{
	  WebDriver driver;
	  private static String VALUE, URL, username, password;
	  private static String usernameLocator, passwordLocator, signInLocator;
//	  public static void main(String[] args)
//	  {
//		  GenericClass gc = new GenericClass();
//		  GenericClass.launchbrowser();
//		  GenericClass.launchURL();
//		  getusername();
//		  getpassword();
//		  
//	  }
	  public static String getPROPERTIES(String KEY) 
	  {  
		try 
		{  
               File file = new File("/home/punithgowda/workspace/ACM/ACM_Automation/src/main/java/pages/Login.prop");  
               FileInputStream inStream = new FileInputStream(file);  
               Properties property = new Properties();  
               property.load(inStream);  
               VALUE = property.getProperty(KEY);  
          }
		catch (IOException e) 
		{  
               // TODO Auto-generated catch block  
               e.printStackTrace();  
          }  
          return VALUE;  
	  	}
	  
	  public static String getURL()
	  {
		  URL = getPROPERTIES("U_URL");
		  return URL;
	  }
	  public static String getusername()
	  {
		  username = getPROPERTIES("C_username");
		  return username;
	  }
	  public static String getusernameLocator()
	  {
		  usernameLocator = getPROPERTIES("L_username");
		  return usernameLocator;
	  }
	  public static String getpassword()
	  {
		  password = getPROPERTIES("C_password");
		  return password;
	  }
	  public static String getpasswordLocator()
	  {
		  passwordLocator = getPROPERTIES("L_password");
		  return passwordLocator;
	  }
	  public LoginPage(WebDriver driver)
	  {
		  this.driver = driver;
	  }
}
	  