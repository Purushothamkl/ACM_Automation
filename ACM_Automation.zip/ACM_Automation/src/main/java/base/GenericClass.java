package base;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GenericClass {
	static String Browser,ImplicitWait, URL;
	public static void main(String[] args)
	{
		launchbrowser();
		launchURL();
	}
	public static void init() throws IOException
	{
		try {
			FileInputStream file = new FileInputStream("/home/punithgowda/workspace/ACM/ACM_Automation/src/main/java/base/data.prop");
			Properties prop = new Properties();
			prop.load(file);
			Browser = prop.getProperty("BrowserType");
			URL = prop.getProperty("URL");
			ImplicitWait = prop.getProperty("ImplicitWait");
						
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	static WebDriver driver;
	public static void launchbrowser()
	{
		try {
			init();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch(Browser){
			case "Firefox":
				System.setProperty("webdriver.Firefox.driver", "/home/punithgowda/Desktop/Selenium/geckodriver");
				System.out.println("Launching Firefox browser");
				driver = new FirefoxDriver();
				break;
			case "Chrome":
				System.setProperty("webdriver.chrome.driver", "/usr/bin/chromedriver");
				System.out.println("Launching Chrome browser");
				driver = new ChromeDriver();
				break;
			default:
				System.out.println("Enter the browser name in the following format - Firefox, Chrome");
				
		}
	}
	public static void launchURL(){
		driver.get(URL);
	}

}