package com.acm.testcases;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import base.GenericClass;
import pages.LoginPage;

public class VerifyLogin extends LoginPage {
	static WebDriver driver;
	
	public VerifyLogin(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	@Test
	public static void verify() throws IOException
	{
		LoginPage lp = new LoginPage(driver);
//		GenericClass.launchbrowser();
//		GenericClass.launchURL();
		driver.get(LoginPage.getURL());
		
		driver.findElement(By.xpath(getusername())).sendKeys(getusernameLocator());
		driver.findElement(By.xpath(getpassword())).sendKeys(getpasswordLocator());
		
	}

	}


