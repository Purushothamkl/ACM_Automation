package pages;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.GenericClass;

public class LoginPage extends GenericClass {
	static WebDriver driver;	
	static String userid, passwd;
	static String usernameXpath, passwordXpath, signInXpath;
	
	public static void main(String[] args){
		launchbrowser();
		launchURL();
		try {
			initXpath();
			init();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}	
	
	public static void init() throws IOException{

		try {
			FileInputStream file = new FileInputStream("/home/punithgowda/workspace/ACM/ACM_Automation/src/main/java/pages/Login.prop");
			Properties prop = new Properties();
			prop.load(file);
			userid=prop.getProperty("username");
			passwd=prop.getProperty("password");
			System.out.println(userid);
			System.out.println(passwd);
						
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public static void initXpath() throws IOException{

		try {
			FileInputStream file = new FileInputStream("/home/punithgowda/workspace/ACM/ACM_Automation/src/main/java/pages/LoginXpath.prop");
			Properties prop = new Properties();
			prop.load(file);
			usernameXpath=prop.getProperty("usernameXpath");
			passwordXpath=prop.getProperty("passwordXpath");
			signInXpath=prop.getProperty("signInXpath");	
			System.out.println(usernameXpath);
			System.out.println(passwordXpath);
			System.out.println(signInXpath);
						
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public LoginPage(WebDriver driver) throws IOException
	{
		LoginPage.driver = driver;
		try {
			LoginPage.init();
			LoginPage.initXpath();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
}
