package com.acm.testcases;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import base.GenericClass;
import pages.LoginPage;

public class VerifyAcmLogin extends LoginPage {
	static WebDriver driver;
	public VerifyAcmLogin(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	@Test
	public static void verify() throws IOException
	{
		LoginPage lp = new LoginPage(driver);
		GenericClass.launchbrowser();
		GenericClass.launchURL();
		driver.findElement(By.xpath("//input[@id='loginId']")).sendKeys("901728");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Qwerty16");
		driver.findElement(By.xpath("//button[@ng-disabled='logonData.signInButtonDisabled']")).click();
	}

	}


